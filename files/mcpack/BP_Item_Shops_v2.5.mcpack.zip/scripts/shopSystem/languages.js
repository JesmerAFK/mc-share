// Language configuration for the shop system
export const supportedLanguages = [
    { id: "en", name: "English" },
    { id: "es", name: "Español (Spanish)" },
    { id: "pt", name: "Português (Portuguese)" },
    { id: "zh", name: "中文 (Mandarin)" },
    { id: "hi", name: "हिन्दी (Hindi)" },
    { id: "id", name: "Bahasa Indonesia (Indonesian)" }
];

// Default language
export const defaultLanguage = "en";

// Translations for all UI text
export const translations = {
    // English translations
    "en": {
        // Common
        "shopOptions": "Shop Options",
        "chooseAction": "Choose an action:",
        "sellItem": "Sell Item",
        "collectRewards": "Collect Rewards",
        "deleteShop": "Delete Shop",
        "cancel": "Cancel",
        "confirm": "Confirm",
        
        // Sell form
        "listItemForSale": "List Item for Sale",
        "selectItemToSell": "Select Item to Sell",
        "shopNameOptional": "Shop Name (Optional)",
        "enterCustomShopName": "Enter a custom shop name",
        "amountToSell": "Amount to Sell",
        "selectCurrency": "Select Currency",
        "pricingMethod": "Pricing Method",
        "pricePerStack": "Price per Stack",
        "pricePerItem": "Price per Item",
        "setPrice": "Set Price (Numbers Only)",
        "enterPrice": "Enter the price",
        "unlimitedStock": "Unlimited Stock",
        
        // Buy form
        "buyItems": "Buy Items",
        "quantityToBuy": "Quantity to Buy",
        "confirmPurchase": "Confirm Purchase",
        "seller": "Seller",
        "item": "Item",
        "price": "Price",
        "confirmPurchaseButton": "Confirm Purchase",
        "cancelButton": "Cancel",
        
        // Shop management
        "shopManagement": "Shop Management",
        "adminControls": "Admin Controls",
        "manageShopListing": "Manage your shop listing:",
        "adminOptionsForShop": "Admin options for this shop:",
        "cancelSale": "Cancel Sale",
        "forceCancelSale": "Force Cancel Sale",
        "buyItem": "Buy Item",
        
        // Language selection
        "selectLanguage": "Select Language",
        "languageChanged": "Language changed to",
        
        // Messages
        "invalidPrice": "Invalid price. Please enter a positive number.",
        "shopNotSelling": "This shop is not selling anything.",
        "noPermissionCancel": "You don't have permission to cancel this sale.",
        "noRewardsToCollect": "You have no rewards to collect.",
        "rewardsCollected": "You have collected your rewards.",
        "purchaseCanceled": "Purchase canceled.",
        "itemListed": "Item listed for sale:",
        "for": "for",
        "each": "each",
        "purchased": "You have purchased",
        "shopDeleted": "Shop deleted! Items have been dropped.",
        "failedToDelete": "Failed to delete shop!",
        "saleCanceled": "Sale canceled. Received",
        "forceCanceled": "Force canceled sale of",
        "shopCreated": "Shop created! You can now sell items here.",
        "needCreativeOrAdmin": "You need to be in Creative mode, have the 'admin' tag, or be the one who placed this shop!",
        "notEnoughCurrency": "You don't have enough",
        "errorProcessingPurchase": "An error occurred while processing the purchase. Please try again.",
        "errorListingItem": "An error occurred while listing the item for sale. Please try again.",
        "all": "all",
        "yourShopCanceled": "Your shop at",
        "wasCanceledBy": "was canceled by"
    },
    
    // Spanish translations
    "es": {
        // Common
        "shopOptions": "Opciones de Tienda",
        "chooseAction": "Elige una acción:",
        "sellItem": "Vender Artículo",
        "collectRewards": "Recoger Recompensas",
        "deleteShop": "Eliminar Tienda",
        "cancel": "Cancelar",
        "confirm": "Confirmar",
        
        // Sell form
        "listItemForSale": "Listar Artículo para Venta",
        "selectItemToSell": "Seleccionar Artículo para Vender",
        "shopNameOptional": "Nombre de Tienda (Opcional)",
        "enterCustomShopName": "Ingresa un nombre personalizado",
        "amountToSell": "Cantidad para Vender",
        "selectCurrency": "Seleccionar Moneda",
        "pricingMethod": "Método de Precio",
        "pricePerStack": "Precio por Pila",
        "pricePerItem": "Precio por Artículo",
        "setPrice": "Establecer Precio (Solo Números)",
        "enterPrice": "Ingresa el precio",
        "unlimitedStock": "Stock Ilimitado",
        
        // Buy form
        "buyItems": "Comprar Artículos",
        "quantityToBuy": "Cantidad a Comprar",
        "confirmPurchase": "Confirmar Compra",
        "seller": "Vendedor",
        "item": "Artículo",
        "price": "Precio",
        "confirmPurchaseButton": "Confirmar Compra",
        "cancelButton": "Cancelar",
        
        // Shop management
        "shopManagement": "Gestión de Tienda",
        "adminControls": "Controles de Administrador",
        "manageShopListing": "Gestiona tu tienda:",
        "adminOptionsForShop": "Opciones de administrador para esta tienda:",
        "cancelSale": "Cancelar Venta",
        "forceCancelSale": "Forzar Cancelación de Venta",
        "buyItem": "Comprar Artículo",
        
        // Language selection
        "selectLanguage": "Seleccionar Idioma",
        "languageChanged": "Idioma cambiado a",
        
        // Messages
        "invalidPrice": "Precio inválido. Por favor ingresa un número positivo.",
        "shopNotSelling": "Esta tienda no está vendiendo nada.",
        "noPermissionCancel": "No tienes permiso para cancelar esta venta.",
        "noRewardsToCollect": "No tienes recompensas para recoger.",
        "rewardsCollected": "Has recogido tus recompensas.",
        "purchaseCanceled": "Compra cancelada.",
        "itemListed": "Artículo listado para venta:",
        "for": "por",
        "each": "cada uno",
        "purchased": "Has comprado",
        "shopDeleted": "¡Tienda eliminada! Los artículos han sido soltados.",
        "failedToDelete": "¡Error al eliminar la tienda!",
        "saleCanceled": "Venta cancelada. Recibido",
        "forceCanceled": "Venta forzada cancelada de",
        "shopCreated": "¡Tienda creada! Ahora puedes vender artículos aquí.",
        "needCreativeOrAdmin": "¡Necesitas estar en modo Creativo, tener la etiqueta 'admin', o ser quien colocó esta tienda!",
        "notEnoughCurrency": "No tienes suficiente",
        "errorProcessingPurchase": "Ocurrió un error al procesar la compra. Por favor, inténtalo de nuevo.",
        "errorListingItem": "Ocurrió un error al listar el artículo para la venta. Por favor, inténtalo de nuevo.",
        "all": "todo",
        "yourShopCanceled": "Tu tienda en",
        "wasCanceledBy": "fue cancelada por"
    },
    
    // Portuguese translations
    "pt": {
        // Common
        "shopOptions": "Opções da Loja",
        "chooseAction": "Escolha uma ação:",
        "sellItem": "Vender Item",
        "collectRewards": "Coletar Recompensas",
        "deleteShop": "Excluir Loja",
        "cancel": "Cancelar",
        "confirm": "Confirmar",
        
        // Sell form
        "listItemForSale": "Listar Item para Venda",
        "selectItemToSell": "Selecionar Item para Vender",
        "shopNameOptional": "Nome da Loja (Opcional)",
        "enterCustomShopName": "Digite um nome personalizado",
        "amountToSell": "Quantidade para Vender",
        "selectCurrency": "Selecionar Moeda",
        "pricingMethod": "Método de Preço",
        "pricePerStack": "Preço por Pilha",
        "pricePerItem": "Preço por Item",
        "setPrice": "Definir Preço (Apenas Números)",
        "enterPrice": "Digite o preço",
        "unlimitedStock": "Estoque Ilimitado",
        
        // Buy form
        "buyItems": "Comprar Itens",
        "quantityToBuy": "Quantidade para Comprar",
        "confirmPurchase": "Confirmar Compra",
        "seller": "Vendedor",
        "item": "Item",
        "price": "Preço",
        "confirmPurchaseButton": "Confirmar Compra",
        "cancelButton": "Cancelar",
        
        // Shop management
        "shopManagement": "Gerenciamento da Loja",
        "adminControls": "Controles de Administrador",
        "manageShopListing": "Gerencie sua loja:",
        "adminOptionsForShop": "Opções de administrador para esta loja:",
        "cancelSale": "Cancelar Venda",
        "forceCancelSale": "Forçar Cancelamento da Venda",
        "buyItem": "Comprar Item",
        
        // Language selection
        "selectLanguage": "Selecionar Idioma",
        "languageChanged": "Idioma alterado para",
        
        // Messages
        "invalidPrice": "Preço inválido. Por favor, digite um número positivo.",
        "shopNotSelling": "Esta loja não está vendendo nada.",
        "noPermissionCancel": "Você não tem permissão para cancelar esta venda.",
        "noRewardsToCollect": "Você não tem recompensas para coletar.",
        "rewardsCollected": "Você coletou suas recompensas.",
        "purchaseCanceled": "Compra cancelada.",
        "itemListed": "Item listado para venda:",
        "for": "por",
        "each": "cada",
        "purchased": "Você comprou",
        "shopDeleted": "Loja excluída! Os itens foram dropados.",
        "failedToDelete": "Falha ao excluir a loja!",
        "saleCanceled": "Venda cancelada. Recebido",
        "forceCanceled": "Venda forçadamente cancelada de",
        "shopCreated": "Loja criada! Agora você pode vender itens aqui.",
        "needCreativeOrAdmin": "Você precisa estar no modo Criativo, ter a tag 'admin', ou ser quem colocou esta loja!",
        "notEnoughCurrency": "Você não tem",
        "errorProcessingPurchase": "Ocorreu um erro ao processar a compra. Por favor, tente novamente.",
        "errorListingItem": "Ocorreu um erro ao listar o item para venda. Por favor, tente novamente.",
        "all": "todos",
        "yourShopCanceled": "Sua loja em",
        "wasCanceledBy": "foi cancelada por"
    },
    
    // Mandarin translations
    "zh": {
        // Common
        "shopOptions": "商店选项",
        "chooseAction": "选择一个操作：",
        "sellItem": "出售物品",
        "collectRewards": "收集奖励",
        "deleteShop": "删除商店",
        "cancel": "取消",
        "confirm": "确认",
        
        // Sell form
        "listItemForSale": "列出物品出售",
        "selectItemToSell": "选择要出售的物品",
        "shopNameOptional": "商店名称（可选）",
        "enterCustomShopName": "输入自定义商店名称",
        "amountToSell": "出售数量",
        "selectCurrency": "选择货币",
        "pricingMethod": "定价方式",
        "pricePerStack": "每堆价格",
        "pricePerItem": "每个价格",
        "setPrice": "设置价格（仅数字）",
        "enterPrice": "输入价格",
        "unlimitedStock": "无限库存",
        
        // Buy form
        "buyItems": "购买物品",
        "quantityToBuy": "购买数量",
        "confirmPurchase": "确认购买",
        "seller": "卖家",
        "item": "物品",
        "price": "价格",
        "confirmPurchaseButton": "确认购买",
        "cancelButton": "取消",
        
        // Shop management
        "shopManagement": "商店管理",
        "adminControls": "管理员控制",
        "manageShopListing": "管理您的商店列表：",
        "adminOptionsForShop": "此商店的管理员选项：",
        "cancelSale": "取消销售",
        "forceCancelSale": "强制取消销售",
        "buyItem": "购买物品",
        
        // Language selection
        "selectLanguage": "选择语言",
        "languageChanged": "语言已更改为",
        
        // Messages
        "invalidPrice": "无效价格。请输入一个正数。",
        "shopNotSelling": "此商店没有出售任何物品。",
        "noPermissionCancel": "您没有权限取消此销售。",
        "noRewardsToCollect": "您没有奖励可收集。",
        "rewardsCollected": "您已收集您的奖励。",
        "purchaseCanceled": "购买已取消。",
        "itemListed": "物品已列出出售：",
        "for": "价格",
        "each": "每个",
        "purchased": "您已购买",
        "shopDeleted": "商店已删除！物品已掉落。",
        "failedToDelete": "删除商店失败！",
        "saleCanceled": "销售已取消。收到",
        "forceCanceled": "强制取消销售",
        "shopCreated": "商店已创建！您现在可以在这里出售物品。",
        "needCreativeOrAdmin": "您需要处于创造模式，拥有'admin'标签，或者是放置此商店的人！",
        "notEnoughCurrency": "您没有足够的",
        "errorProcessingPurchase": "处理购买时发生错误。请再试一次。",
        "errorListingItem": "列出物品出售时发生错误。请再试一次。",
        "all": "全部",
        "yourShopCanceled": "您在",
        "wasCanceledBy": "的商店被取消，取消者为"
    },
    
    // Hindi translations
    "hi": {
        // Common
        "shopOptions": "दुकान विकल्प",
        "chooseAction": "एक कार्रवाई चुनें:",
        "sellItem": "वस्तु बेचें",
        "collectRewards": "पुरस्कार एकत्र करें",
        "deleteShop": "दुकान हटाएं",
        "cancel": "रद्द करें",
        "confirm": "पुष्टि करें",
        
        // Sell form
        "listItemForSale": "बिक्री के लिए वस्तु सूचीबद्ध करें",
        "selectItemToSell": "बेचने के लिए वस्तु चुनें",
        "shopNameOptional": "दुकान का नाम (वैकल्पिक)",
        "enterCustomShopName": "एक कस्टम दुकान नाम दर्ज करें",
        "amountToSell": "बेचने की मात्रा",
        "selectCurrency": "मुद्रा चुनें",
        "pricingMethod": "मूल्य निर्धारण विधि",
        "pricePerStack": "स्टैक प्रति मूल्य",
        "pricePerItem": "वस्तु प्रति मूल्य",
        "setPrice": "मूल्य निर्धारित करें (केवल संख्याएँ)",
        "enterPrice": "मूल्य दर्ज करें",
        "unlimitedStock": "असीमित स्टॉक",
        
        // Buy form
        "buyItems": "वस्तुएँ खरीदें",
        "quantityToBuy": "खरीदने की मात्रा",
        "confirmPurchase": "खरीदारी की पुष्टि करें",
        "seller": "विक्रेता",
        "item": "वस्तु",
        "price": "मूल्य",
        "confirmPurchaseButton": "खरीदारी की पुष्टि करें",
        "cancelButton": "रद्द करें",
        
        // Shop management
        "shopManagement": "दुकान प्रबंधन",
        "adminControls": "व्यवस्थापक नियंत्रण",
        "manageShopListing": "अपनी दुकान की सूची प्रबंधित करें:",
        "adminOptionsForShop": "इस दुकान के लिए व्यवस्थापक विकल्प:",
        "cancelSale": "बिक्री रद्द करें",
        "forceCancelSale": "बिक्री रद्द करने के लिए मजबूर करें",
        "buyItem": "वस्तु खरीदें",
        
        // Language selection
        "selectLanguage": "भाषा चुनें",
        "languageChanged": "भाषा बदल दी गई है",
        
        // Messages
        "invalidPrice": "अमान्य मूल्य। कृपया एक सकारात्मक संख्या दर्ज करें।",
        "shopNotSelling": "यह दुकान कुछ भी नहीं बेच रही है।",
        "noPermissionCancel": "आपके पास इस बिक्री को रद्द करने की अनुमति नहीं है।",
        "noRewardsToCollect": "आपके पास एकत्र करने के लिए कोई पुरस्कार नहीं है।",
        "rewardsCollected": "आपने अपने पुरस्कार एकत्र कर लिए हैं।",
        "purchaseCanceled": "खरीदारी रद्द की गई।",
        "itemListed": "बिक्री के लिए सूचीबद्ध वस्तु:",
        "for": "के लिए",
        "each": "प्रत्येक",
        "purchased": "आपने खरीदा है",
        "shopDeleted": "दुकान हटा दी गई! वस्तुएँ गिरा दी गई हैं।",
        "failedToDelete": "दुकान हटाने में विफल!",
        "saleCanceled": "बिक्री रद्द की गई। प्राप्त हुआ",
        "forceCanceled": "बिक्री जबरदस्ती रद्द की गई",
        "shopCreated": "दुकान बनाई गई! अब आप यहां वस्तुएँ बेच सकते हैं।",
        "needCreativeOrAdmin": "आपको क्रिएटिव मोड में होना चाहिए, 'admin' टैग होना चाहिए, या इस दुकान को रखने वाला होना चाहिए!",
        "notEnoughCurrency": "आपके पास पर्याप्त नहीं है",
        "errorProcessingPurchase": "खरीदारी प्रक्रिया में त्रुटि हुई। कृपया पुनः प्रयास करें।",
        "errorListingItem": "वस्तु को बिक्री के लिए सूचीबद्ध करने में त्रुटि हुई। कृपया पुनः प्रयास करें।",
        "all": "सभी",
        "yourShopCanceled": "आपकी दुकान",
        "wasCanceledBy": "पर रद्द कर दी गई है"
    },
    
    // Indonesian translations
    "id": {
        // Common
        "shopOptions": "Opsi Toko",
        "chooseAction": "Pilih tindakan:",
        "sellItem": "Jual Barang",
        "collectRewards": "Kumpulkan Hadiah",
        "deleteShop": "Hapus Toko",
        "cancel": "Batal",
        "confirm": "Konfirmasi",
        
        // Sell form
        "listItemForSale": "Daftar Barang untuk Dijual",
        "selectItemToSell": "Pilih Barang untuk Dijual",
        "shopNameOptional": "Nama Toko (Opsional)",
        "enterCustomShopName": "Masukkan nama toko kustom",
        "amountToSell": "Jumlah untuk Dijual",
        "selectCurrency": "Pilih Mata Uang",
        "pricingMethod": "Metode Penetapan Harga",
        "pricePerStack": "Harga per Tumpukan",
        "pricePerItem": "Harga per Barang",
        "setPrice": "Tetapkan Harga (Hanya Angka)",
        "enterPrice": "Masukkan harga",
        "unlimitedStock": "Stok Tidak Terbatas",
        
        // Buy form
        "buyItems": "Beli Barang",
        "quantityToBuy": "Jumlah untuk Dibeli",
        "confirmPurchase": "Konfirmasi Pembelian",
        "seller": "Penjual",
        "item": "Barang",
        "price": "Harga",
        "confirmPurchaseButton": "Konfirmasi Pembelian",
        "cancelButton": "Batal",
        
        // Shop management
        "shopManagement": "Manajemen Toko",
        "adminControls": "Kontrol Admin",
        "manageShopListing": "Kelola daftar toko Anda:",
        "adminOptionsForShop": "Opsi admin untuk toko ini:",
        "cancelSale": "Batalkan Penjualan",
        "forceCancelSale": "Paksa Batalkan Penjualan",
        "buyItem": "Beli Barang",
        
        // Language selection
        "selectLanguage": "Pilih Bahasa",
        "languageChanged": "Bahasa diubah menjadi",
        
        // Messages
        "invalidPrice": "Harga tidak valid. Harap masukkan angka positif.",
        "shopNotSelling": "Toko ini tidak menjual apa pun.",
        "noPermissionCancel": "Anda tidak memiliki izin untuk membatalkan penjualan ini.",
        "noRewardsToCollect": "Anda tidak memiliki hadiah untuk dikumpulkan.",
        "rewardsCollected": "Anda telah mengumpulkan hadiah Anda.",
        "purchaseCanceled": "Pembelian dibatalkan.",
        "itemListed": "Barang terdaftar untuk dijual:",
        "for": "untuk",
        "each": "masing-masing",
        "purchased": "Anda telah membeli",
        "shopDeleted": "Toko dihapus! Barang telah dijatuhkan.",
        "failedToDelete": "Gagal menghapus toko!",
        "saleCanceled": "Penjualan dibatalkan. Diterima",
        "forceCanceled": "Penjualan dipaksa dibatalkan",
        "shopCreated": "Toko dibuat! Anda sekarang dapat menjual barang di sini.",
        "needCreativeOrAdmin": "Anda perlu berada dalam mode Kreatif, memiliki tag 'admin', atau menjadi orang yang menempatkan toko ini!",
        "notEnoughCurrency": "Anda tidak memiliki cukup",
        "errorProcessingPurchase": "Terjadi kesalahan saat memproses pembelian. Silakan coba lagi.",
        "errorListingItem": "Terjadi kesalahan saat mendaftarkan barang untuk dijual. Silakan coba lagi.",
        "all": "semua",
        "yourShopCanceled": "Toko Anda di",
        "wasCanceledBy": "dibatalkan oleh"
    }
};

// Function to get text in the selected language
export function getText(key, language) {
    // If the language doesn't exist or the key doesn't exist in that language, fall back to English
    if (!translations[language] || !translations[language][key]) {
        return translations[defaultLanguage][key] || key;
    }
    return translations[language][key];
}
